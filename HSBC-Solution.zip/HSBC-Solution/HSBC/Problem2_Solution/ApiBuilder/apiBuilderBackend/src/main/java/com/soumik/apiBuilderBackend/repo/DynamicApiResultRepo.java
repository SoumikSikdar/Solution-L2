package com.soumik.apiBuilderBackend.repo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class DynamicApiResultRepo {

    @Autowired
    private EntityManager entityManager;

    public List<Object> getDynamicApiResultSet(String queryText) {
        Query query = entityManager.createNativeQuery(queryText);
        List<Object> apiResultSet =  query.getResultList();
        return apiResultSet;
    }
}
