package com.soumik.apiBuilderBackend.service;

import com.soumik.apiBuilderBackend.model.ApiBuilderDto;
import com.soumik.apiBuilderBackend.model.ApiMetadata;
import com.soumik.apiBuilderBackend.model.ApiSummaryDto;
import com.soumik.apiBuilderBackend.model.FilterValueDto;
import com.soumik.apiBuilderBackend.repo.ApiBuilderRepo;
import com.soumik.apiBuilderBackend.repo.DataSetDetailsRepo;
import com.soumik.apiBuilderBackend.repo.DynamicApiResultRepo;
import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ApiBuilderService {

    @Autowired
    ApiBuilderRepo apiBuilderRepo;

    @Autowired
    DataSetDetailsRepo dataSetDetailsRepo;

    @Autowired
    DynamicApiResultRepo dynamicApiResultRepo;


    @Autowired
    private EntityManager entityManager;

    public List<String> getColumnNames(String tableName) {
        String db_tableName = "";
        if(tableName.equals("CorporateAction")) {
            db_tableName ="ca_event";
        }
        return dataSetDetailsRepo.getColumnNames(db_tableName);
    }

    public String saveDynamicApi(ApiBuilderDto dynamicApiData) {
        try {
            String queryText = buildSelectQuery(dynamicApiData);
            ApiMetadata entity = toEntity(dynamicApiData, queryText);
            apiBuilderRepo.save(entity);
            return "Saved";
        } catch (Exception e) {
            return "Failed to Save";
        }
    }

    private String buildSelectQuery(ApiBuilderDto dto) {

        String db_tableName = "";
        StringBuilder query = new StringBuilder("SELECT * FROM ");
        if(dto.getDataSet().equals("CorporateAction")) {
            db_tableName ="ca_event";
        }
        query.append(db_tableName);

        List<FilterValueDto> filters = dto.getFilterValue();
        if (filters != null && !filters.isEmpty()) {
            query.append(" WHERE ");

            // Build conditions like "dataPoint = 'value'"
            String conditions = filters.stream()
                    .map(fv -> fv.getDataPoint() + " = '" + escapeSql(fv.getValue()) + "'")
                    .collect(Collectors.joining(" AND "));

            query.append(conditions);
        }

        return query.toString();
    }

    private String escapeSql(String value) {
        if (value == null) return null;
        return value.replace("'", "''");
    }

    public ApiMetadata toEntity(ApiBuilderDto dto, String queryText) {
        ApiMetadata metadata = new ApiMetadata();
        metadata.setApi_name(dto.getApi_name());
        metadata.setDataSet(dto.getDataSet());
        metadata.setQuery_text(queryText);  // the generated SQL query string
        metadata.setCreated_at(new Date());
        metadata.setCreated_by("Soumik");
        return metadata;
    }


    public List<ApiSummaryDto> getSavedDynamicApis() {
        List<ApiSummaryDto> dataSets = apiBuilderRepo.findApiNameAndQueryText();
        return dataSets;
    }

    public List<Object> fetchDynamicApiData(String queryText) {
        List<Object> apiResultSet  = dynamicApiResultRepo.getDynamicApiResultSet(queryText);
        return apiResultSet;
    }
}
