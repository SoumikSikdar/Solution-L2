package com.soumik.apiBuilderBackend.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ApiBuilderDto {

    private String api_name;
    private List<FilterValueDto> filterValue;
    private String dataSet;
}
