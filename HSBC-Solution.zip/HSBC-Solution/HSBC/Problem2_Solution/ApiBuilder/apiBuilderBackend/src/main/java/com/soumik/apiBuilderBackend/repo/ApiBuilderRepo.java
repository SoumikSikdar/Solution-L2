package com.soumik.apiBuilderBackend.repo;

import com.soumik.apiBuilderBackend.model.ApiMetadata;
import com.soumik.apiBuilderBackend.model.ApiSummaryDto;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApiBuilderRepo extends CrudRepository<ApiMetadata, Long> {

    @Query("SELECT a.api_name FROM ApiMetadata a")
    List<String> findDistinctDataSets();

    @Query("SELECT new com.soumik.apiBuilderBackend.model.ApiSummaryDto(a.api_name, a.query_text) FROM ApiMetadata a")
    List<ApiSummaryDto> findApiNameAndQueryText();

}


