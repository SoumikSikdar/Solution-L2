package com.soumik.apiBuilderBackend.model;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FilterValueDto {
    private String dataPoint;
    private String value;

    // Getters and Setters
}
