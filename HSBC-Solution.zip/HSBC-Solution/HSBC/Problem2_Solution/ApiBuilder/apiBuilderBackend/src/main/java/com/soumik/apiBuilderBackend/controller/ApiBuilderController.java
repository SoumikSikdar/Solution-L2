package com.soumik.apiBuilderBackend.controller;

import com.soumik.apiBuilderBackend.model.ApiBuilderDto;
import com.soumik.apiBuilderBackend.model.ApiMetadata;
import com.soumik.apiBuilderBackend.model.ApiSummaryDto;
import com.soumik.apiBuilderBackend.service.ApiBuilderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ApiBuilderController {

    @Autowired
    ApiBuilderService apiBuilderService;

    @GetMapping("/getColumnNamesByTable")
    public ResponseEntity<List<String>> getColumnNames(@RequestParam("tableName") String tableName) {
        List<String> columnNames = apiBuilderService.getColumnNames(tableName);
        return ResponseEntity.ok(columnNames);
    }


    @PostMapping("/saveDynamicApi")
    public ResponseEntity<String> saveDynamicApi(@RequestBody ApiBuilderDto dynamicApiRequest) {
        String status = apiBuilderService.saveDynamicApi(dynamicApiRequest);
        return ResponseEntity.ok(status);
    }

    @GetMapping("/getSavedDynamicApis")
    public ResponseEntity<List<ApiSummaryDto>> getSavedDynamicApis() {
        List<ApiSummaryDto> columnNames = apiBuilderService.getSavedDynamicApis();
        return ResponseEntity.ok(columnNames);
    }

    @GetMapping("/fetchDynamicApiData")
    public ResponseEntity<List<Object>> fetchDynamicApiData(@RequestParam("queryText") String queryText) {
        List<Object> apiData = apiBuilderService.fetchDynamicApiData(queryText);
        return ResponseEntity.ok(apiData);
    }

}
