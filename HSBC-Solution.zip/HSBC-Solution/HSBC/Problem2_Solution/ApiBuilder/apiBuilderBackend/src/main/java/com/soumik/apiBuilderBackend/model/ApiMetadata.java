package com.soumik.apiBuilderBackend.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Component
@Getter
@Setter
@Entity
@Table(name = "DYNAMIC_API_METADATA")
public class ApiMetadata {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "apiBuilder_id_generator")
    @SequenceGenerator(
            name = "apiBuilder_id_generator",
            sequenceName = "apiBuilder_id_seq",
            allocationSize = 1
    )
    private Long idSerial;
    private String api_name;
    private String query_text;
    private String dataSet;
    private String created_by ;
    private Date created_at ;
}
