package com.soumik.apiBuilderBackend.repo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class DataSetDetailsRepo {

    @Autowired
    private EntityManager entityManager;

    public List<String> getColumnNames(String tableName) {

        String sql = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS\n" +
                "WHERE TABLE_NAME = :tableName";

        Query query = entityManager.createNativeQuery(sql)
                .setParameter("tableName", tableName);
        List<String> db_tableName =  query.getResultList();
        return db_tableName;
    }
}
