import React from 'react'
import './App.css'
import ApiDataFetch from './component/ApiDataFetch'
import ApiCreatorForm from './component/ApiCreatorForm'

function App() {
  return (
    <div className="App">
      <h1 style={{ fontSize: '2rem', fontWeight: 700, marginBottom: '2rem', textAlign: 'left', letterSpacing: 1 }}>API Builder</h1>
      <div style={{ display: 'flex', gap: '2rem' }}>
        <ApiCreatorForm />
        <ApiDataFetch />
      </div>
    </div>

  )
}

export default App
