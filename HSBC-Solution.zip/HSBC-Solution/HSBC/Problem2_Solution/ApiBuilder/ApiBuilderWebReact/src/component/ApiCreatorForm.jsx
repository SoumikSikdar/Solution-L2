import React, { useState } from 'react'
import axios from 'axios'
import { useEffect } from 'react'
import { FaPlus, FaTrash } from 'react-icons/fa';

function ApiCreatorForm() {
    const [datasets, setDatasets] = useState(['CorporateAction'])
    const [dataPoints, setDataPoints] = useState(['Event type'])
    const [selectedDataset, setSelectedDataset] = useState('')
    const [selectedDataPoint, setSelectedDataPoint] = useState('')
    const [filterValue, setFilterValue] = useState('')
    const [apiName, setApiName] = useState('')
    const [filters, setFilters] = useState([
        { dataPoint: '', value: '' }
    ])

    useEffect(() => {
        axios.get('http://localhost:8085/getColumnNamesByTable?tableName=CorporateAction')
            .then(response => {
                setDataPoints(response.data || ['EventType'])
                console.log(response.data);
            })
            .catch(error => {
                console.error(error);
            });
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault()
        const apiConfig = {
            selectedDataset,
            filters,
            apiName
        }
        console.log('API Config:', apiConfig);
        let dynamicApiRequest = buildApiMetadataObject(apiConfig);

        axios.post('http://localhost:8085/saveDynamicApi', dynamicApiRequest,
            {
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => {
                alert(response.data);
            })
            .catch(error => {
                console.error(error);
            });
    }

    const handleFilterChange = (index, field, newValue) => {
        const updatedFilters = filters.map((filter, i) =>
            i === index ? { ...filter, [field]: newValue } : filter
        )
        setFilters(updatedFilters)
    }

    const handleAddFilter = () => {
        setFilters([...filters, { dataPoint: '', value: '' }])
    }

    const buildApiMetadataObject = (apiConfig) => {
        const apiMetadata = {
            api_name: apiConfig.apiName,
            dataSet: selectedDataset,
            filterValue: apiConfig.filters
        }
        return apiMetadata
    }


    // Import icons from react-icons

    return (

        <div style={{ maxWidth: 1000, padding: '2rem', background: '#f8f9fa', borderRadius: 12, boxShadow: '0 2px 12px rgba(0,0,0,0.07)' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', marginBottom: '2rem', gap: '1.5rem' }}>
                <div>
                    <label htmlFor="dataset-select" style={{ fontWeight: 500, marginRight: 4 }}> DataSet:</label>
                    <select
                        id="dataset-select"
                        value={selectedDataset}
                        onChange={e => setSelectedDataset(e.target.value)}
                        style={{
                            padding: '0.5rem 1rem',
                            borderRadius: 6,
                            border: '1px solid #ccc',
                            background: '#fff',
                            fontSize: 16,
                            minWidth: 160
                        }}
                    >
                        <option value="">--Choose a dataset--</option>
                        {datasets.map(ds => (
                            <option key={ds} value={ds}>{ds}</option>
                        ))}
                    </select>
                </div>
                <div style={{ flex: 1, display: 'flex', alignItems: 'flex-start' }}>
                    <label htmlFor="api-name-input" style={{ fontWeight: 500, marginRight: 4, marginTop: 5 }}>Add API name:</label>
                    <input
                        id="api-name-input"
                        type="text"
                        placeholder="Enter API name"
                        onChange={e => setApiName(e.target.value)}
                        value={apiName}
                        style={{
                            maxWidth: 300,
                            padding: '0.5rem 1rem',
                            borderRadius: 6,
                            border: '1px solid #ccc',
                            fontSize: 16,
                            flex: 1
                        }}
                    />
                </div>
            </div>
            <div>
                {filters.map((filter, idx) => (
                    <div
                        key={idx}
                        style={{
                            display: 'flex',
                            alignItems: 'flex-start',
                            background: '#fff',
                            borderRadius: 8,
                            boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
                            padding: '0.5rem',
                            marginBottom: '1rem',
                            gap: '1rem'
                        }}
                    >
                        <div style={{ flex: 2 }}>
                            <label htmlFor={`datapoint-select-${idx}`} style={{ fontWeight: 500, marginRight: 8 }}>Data Point:</label>
                            <select
                                id={`datapoint-select-${idx}`}
                                value={filter.dataPoint}
                                onChange={e => handleFilterChange(idx, 'dataPoint', e.target.value)}
                                style={{
                                    padding: '0.5rem 1rem',
                                    borderRadius: 6,
                                    border: '1px solid #ccc',
                                    background: '#f6f6f6',
                                    fontSize: 16,
                                    minWidth: 160
                                }}
                            >
                                <option value="">--Choose a data point--</option>
                                {dataPoints.map(dp => (
                                    <option key={dp} value={dp}>{dp}</option>
                                ))}
                            </select>
                        </div>
                        <div style={{ flex: 1, display: 'flex', alignItems: 'flex-start' }}>
                            <label htmlFor={`filter-input-${idx}`} style={{ fontWeight: 500, marginRight: 4, marginTop: 5 }}> Filter:</label>
                            <input
                                id={`filter-input-${idx}`}
                                type="text"
                                placeholder="Enter Filter value"
                                value={filter.value}
                                onChange={e => handleFilterChange(idx, 'value', e.target.value)}
                                style={{
                                    maxWidth: 200,
                                    padding: '0.5rem 1rem',
                                    borderRadius: 6,
                                    border: '1px solid #ccc',
                                    fontSize: 16,
                                    float: 'right',
                                    flex: 1
                                }}
                            />
                        </div>
                        {idx !== filters.length - 1 && (
                            <button
                                style={{
                                    marginLeft: 12,
                                    padding: '0.5rem 1.2rem',
                                    borderRadius: 6,
                                    border: 'none',
                                    background: '#dc3545',
                                    color: '#fff',
                                    fontWeight: 600,
                                    fontSize: 16,
                                    cursor: 'pointer',
                                    transition: 'background 0.2s',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                }}
                                onClick={() => setFilters(filters.filter((_, i) => i !== idx))}
                                title="Delete"
                            >
                                <FaTrash />
                            </button>
                        )}
                        {idx === filters.length - 1 && (
                            <button
                                style={{
                                    marginLeft: 12,
                                    padding: '0.5rem 1.2rem',
                                    borderRadius: 6,
                                    border: 'none',
                                    background: '#007bff',
                                    color: '#fff',
                                    fontWeight: 600,
                                    fontSize: 16,
                                    cursor: 'pointer',
                                    transition: 'background 0.2s',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                }}
                                onClick={handleAddFilter}
                                title="Add"
                            >
                                <FaPlus />
                            </button>
                        )}
                    </div>
                ))}
            </div>
            <div style={{ textAlign: 'right', marginTop: '2rem' }}>
                <button
                    type="submit"
                    style={{
                        padding: '0.75rem 2rem',
                        borderRadius: 6,
                        border: 'none',
                        background: '#28a745',
                        color: '#fff',
                        fontWeight: 700,
                        fontSize: 18,
                        cursor: 'pointer',
                        boxShadow: '0 1px 4px rgba(0,0,0,0.07)'
                    }}
                    onClick={handleSubmit}
                >
                    Submit
                </button>
            </div>
        </div>
    )
}

export default ApiCreatorForm