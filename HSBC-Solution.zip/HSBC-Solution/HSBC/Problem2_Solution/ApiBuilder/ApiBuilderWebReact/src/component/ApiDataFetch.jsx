import React, { useEffect, useState } from 'react';
import axios from 'axios';  

const ApiDataFetch = () => {
    const [apiOptions, setApiOptions] = useState(['']);
    const [selectedApi, setSelectedApi] = useState('');
    const [apiData, setApiData] = useState('');
    const [loading, setLoading] = useState(false);

    useEffect(() => {        
        axios.get('http://localhost:8085/getSavedDynamicApis')
            .then(response => {
                setApiOptions(response.data);
                console.log(response.data);
            })
            .catch(error => {
                console.error(error);
            });
    }, []);

    const handleFetch = async () => {
        setLoading(true);
        setApiData('');
        let querytext = apiOptions.find(api => api.api_name === selectedApi)?.query_text || '';
        try {
            const response = await axios.get(`http://localhost:8085/fetchDynamicApiData?queryText=${querytext}`);
            setApiData(JSON.stringify(response.data, null, 2));
        } catch (error) {
            console.error('Error fetching API data:', error);
            setApiData('Error fetching data. Please check the console for details.');
        }       
        setLoading(false);
    };

    return (
        <div
            style={{
                maxWidth: 800,
                padding: '2rem',
                fontFamily: 'sans-serif',
                background: '#fff',
                borderRadius: 10,
                boxShadow: '0 2px 12px rgba(0,0,0,0.07)'
            }}
        >
            <div
                style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    marginBottom: '2rem'
                }}
            >
                <label htmlFor="api-select" style={{ fontWeight: 400, fontSize: 16 }}>
                    Api Name:
                </label>
                <select
                    id="api-select"
                    value={selectedApi}
                    onChange={e => setSelectedApi(e.target.value)}
                    style={{
                        padding: '0.5rem 0.5rem',
                        borderRadius: 6,
                        border: '1px solid #d1d5db',
                        fontSize: 14,
                        background: '#f9fafb'
                    }}
                >
                    <option value="" disabled>Select an API</option>    
                    {apiOptions.map((api, index) => (
                                    <option key={index} value={api.api_name}>{api.api_name}</option>))}

                </select>
                <button
                    onClick={handleFetch}
                    disabled={loading}
                    style={{
                        background: '#2563eb',
                        color: '#fff',
                        border: 'none',
                        borderRadius: 6,
                        padding: '0.6rem 1.4rem',
                        fontWeight: 600,
                        fontSize: 15,
                        cursor: loading ? 'not-allowed' : 'pointer',
                        boxShadow: '0 1px 4px rgba(37,99,235,0.08)'
                    }}
                >
                    {loading ? 'Fetching...' : 'Fetch'}
                </button>
            </div>
            <div style={{ marginTop: '1rem' }}>
                <textarea
                    readOnly
                    rows={15}
                    style={{
                        width: '90%',
                        fontFamily: 'monospace',
                        resize: 'vertical',
                        padding: '1rem',
                        borderRadius: 8,
                        border: '1px solid #e5e7eb',
                        background: '#f3f4f6',
                        fontSize: 14
                    }}
                    value={apiData}
                    placeholder="Fetched API data will appear here..."
                />
            </div>
        </div>
    );
};

export default ApiDataFetch;