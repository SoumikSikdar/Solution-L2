package com.soumik.dataFeedDeltaProcessing.util;

public enum FeedType {
    JSON, XML, CSV, UNKNOWN
}

