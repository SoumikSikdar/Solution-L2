package com.soumik.dataFeedDeltaProcessing.util;

public class InvalidFeedDataException extends RuntimeException {
    public InvalidFeedDataException(String message) {
        super(message);
    }
}

