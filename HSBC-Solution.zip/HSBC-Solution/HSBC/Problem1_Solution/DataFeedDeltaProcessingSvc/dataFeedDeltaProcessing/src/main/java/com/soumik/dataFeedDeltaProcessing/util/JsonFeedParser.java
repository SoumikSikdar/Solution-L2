package com.soumik.dataFeedDeltaProcessing.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.soumik.dataFeedDeltaProcessing.model.CorporateActionEvent;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class JsonFeedParser implements FeedParser{

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public List<CorporateActionEvent> parse(String json) {
        List<CorporateActionEvent> events = new ArrayList<>();

        // Convert JSON string to InputStream
        InputStream inputStream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));

        try (JsonParser parser = objectMapper.getFactory().createParser(inputStream)) {
            // Expecting an array
            if (parser.nextToken() != JsonToken.START_ARRAY) {
                throw new IllegalStateException("Expected JSON array");
            }

            // Read each object inside array
            while (parser.nextToken() != JsonToken.END_ARRAY) {
                CorporateActionEvent event = objectMapper.readValue(parser, CorporateActionEvent.class);
                events.add(event);
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to parse JSON stream", e);
        }

        return events;
    }
}


