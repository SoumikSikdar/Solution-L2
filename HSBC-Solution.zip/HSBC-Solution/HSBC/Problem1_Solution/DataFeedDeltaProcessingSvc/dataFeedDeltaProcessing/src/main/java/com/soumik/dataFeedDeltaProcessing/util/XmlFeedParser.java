package com.soumik.dataFeedDeltaProcessing.util;

import com.soumik.dataFeedDeltaProcessing.model.CorporateActionEvent;

import java.util.List;

public class XmlFeedParser implements FeedParser{
    @Override
    public List<CorporateActionEvent> parse(String content) {
        // Parser to parse xml feed
        return List.of();
    }
}
