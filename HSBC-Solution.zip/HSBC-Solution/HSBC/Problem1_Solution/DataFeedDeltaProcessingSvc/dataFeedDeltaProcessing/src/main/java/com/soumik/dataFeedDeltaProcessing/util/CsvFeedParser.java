package com.soumik.dataFeedDeltaProcessing.util;

import com.soumik.dataFeedDeltaProcessing.model.CorporateActionEvent;

import java.util.List;

public class CsvFeedParser implements FeedParser{
    @Override
    public List<CorporateActionEvent> parse(String content) {
        // Parser to parse csv feed
        return List.of();
    }
}
