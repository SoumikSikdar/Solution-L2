package com.soumik.dataFeedDeltaProcessing.service;

import com.soumik.dataFeedDeltaProcessing.model.CorporateActionChangeDetails;
import com.soumik.dataFeedDeltaProcessing.model.CorporateActionEvent;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Component
public class DeltaDataProcessingService {

    private final WebClient webClient;

    public DeltaDataProcessingService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    // Update Row with fields updated
    public String processFeedForUpdate(CorporateActionEvent currentCoacEvent) {
        // call persistence service to save the data
        return publishEventForPersistence(currentCoacEvent); // JPA tracks only changed fields
    }

    //Insert new Row
    public String processFeedForInsert(CorporateActionEvent newCoacEvent) {
        return publishEventForPersistence(newCoacEvent);
    }

    public void updateCorporateActionEventWithChangedData(CorporateActionEvent coacEvents, Map<String, Object> changes) {
        if (changes.containsKey("gross_rate")) {
            coacEvents.setGrossRate((BigDecimal) changes.get("gross_rate"));
        }

        if (changes.containsKey("fx_rate")) {
            coacEvents.setFxRate((BigDecimal) changes.get("fx_rate"));
        }

        if (changes.containsKey("fees")) {
            coacEvents.setFees((BigDecimal) changes.get("fees"));
        }

        if (changes.containsKey("effective_date")) {
            coacEvents.setEffectiveDate((Date) changes.get("effective_date"));
        }

        if (changes.containsKey("payment_date")) {
            coacEvents.setPaymentDate((Date) changes.get("payment_date"));
        }

        coacEvents.setVersion((Long) changes.get("version"));
    }

    public Map<String, Object> findChangedFields(CorporateActionEvent oldData, CorporateActionEvent newData) {
        Map<String, Object> changes = new HashMap<>();

        if (newData == null || oldData == null) {
            throw new IllegalArgumentException("CorporateActionEvent objects cannot be null");
        }

        if (!Objects.equals(newData.getEventType(), oldData.getEventType())) {
            changes.put("event_type", newData.getEventType());
        }
        if (!Objects.equals(newData.getSecurityName(), oldData.getSecurityName())) {
            changes.put("security_name", newData.getSecurityName());
        }
        if (!Objects.equals(newData.getTicker(), oldData.getTicker())) {
            changes.put("ticker", newData.getTicker());
        }
        if (!Objects.equals(newData.getSedol(), oldData.getSedol())) {
            changes.put("sedol", newData.getSedol());
        }
        if (!Objects.equals(newData.getCusip(), oldData.getCusip())) {
            changes.put("cusip", newData.getCusip());
        }
        if (!Objects.equals(newData.getSector(), oldData.getSector())) {
            changes.put("sector", newData.getSector());
        }
        if (!Objects.equals(newData.getGrossRate(), oldData.getGrossRate())) {
            changes.put("gross_rate", newData.getGrossRate());
        }
        if (!Objects.equals(newData.getFxRate(), oldData.getFxRate())) {
            changes.put("fx_rate", newData.getFxRate());
        }
        if (!Objects.equals(newData.getFees(), oldData.getFees())) {
            changes.put("fees", newData.getFees());
        }
        if (!Objects.equals(newData.getAnnouncementDate(), oldData.getAnnouncementDate())) {
            changes.put("announcement_date", newData.getAnnouncementDate());
        }
        if (!Objects.equals(newData.getEffectiveDate(), oldData.getEffectiveDate())) {
            changes.put("effective_date", newData.getEffectiveDate());
        }
        if (!Objects.equals(newData.getPaymentDate(), oldData.getPaymentDate())) {
            changes.put("payment_date", newData.getPaymentDate());
        }
        if (!Objects.equals(newData.getCreateDate(), oldData.getCreateDate())) {
            changes.put("create_date", newData.getCreateDate());
        }
        if (!Objects.equals(newData.getUpdateDate(), oldData.getUpdateDate())) {
            changes.put("update_date", newData.getUpdateDate());
        }
        if (!Objects.equals(newData.getCreatedBy(), oldData.getCreatedBy())) {
            changes.put("created_by", newData.getCreatedBy());
        }
        if (!Objects.equals(newData.getUpdatedBy(), oldData.getUpdatedBy())) {
            changes.put("updated_by", newData.getUpdatedBy());
        }

        changes.put("version", oldData.getVersion() + 1);

        return changes;

    }

    // microservice call to save the event data
    public String publishEventForPersistence(CorporateActionEvent event) {
        try {
            return webClient
                    .post()
                    .uri("http://dataFeedPersistence/persistEvent")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(event)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();  // Synchronous for simplicity
        } catch (Exception ex) {
            return "failed";
        }
    }

    // microservice call to save the event Audit data
    // Not the Best way. There are better ways like
    // 1) publish to queue. Audit service processes form queue
    // 2) USe CDC like Debezium
    // 3) DB Triggers
    public String saveAuditDetails(CorporateActionChangeDetails corporateActionChangeDetails) {
        try {
            return webClient
                    .post()
                    .uri("http://dataFeedAudit/saveDataFeedAudit")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(corporateActionChangeDetails)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();
        } catch (Exception ex) {
            return "failed";
        }
    }
}
