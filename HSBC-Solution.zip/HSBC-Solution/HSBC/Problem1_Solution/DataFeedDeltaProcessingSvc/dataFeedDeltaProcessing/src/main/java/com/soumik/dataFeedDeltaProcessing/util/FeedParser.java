package com.soumik.dataFeedDeltaProcessing.util;
import com.soumik.dataFeedDeltaProcessing.model.CorporateActionEvent;
import java.util.List;

public interface FeedParser {
    List<CorporateActionEvent> parse(String content);
}
