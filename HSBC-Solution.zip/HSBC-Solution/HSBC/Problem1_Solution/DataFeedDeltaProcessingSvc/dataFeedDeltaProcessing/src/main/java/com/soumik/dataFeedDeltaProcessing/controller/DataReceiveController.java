package com.soumik.dataFeedDeltaProcessing.controller;

import com.soumik.dataFeedDeltaProcessing.service.DataReceiveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DataReceiveController {

    @Autowired
    DataReceiveService dataReceiveService;

    // Ideally, this controller will subscribe to a Queue e.g. SQS/Kafka and will receive events from the queue
    // for demo purpose created this as an endpoint

    /// Sample Event
    /*
        [
        {
                "eventId": 4,
                "eventType": "Dividend",
                "securityName": "Honda",
                "ticker": "HON",
                "sedol": "123MH",
                "cusip": "2E4RT5M4",
                "sector": "IT",
                "grossRate": 67.78,
                "fxRate": 90.12,
                "fees": 678.56,
                "announcementDate": "2025-06-06T08:10:48.118+00:00",
                "effectiveDate": "2025-06-06T08:10:48.118+00:00",
                "paymentDate": "2025-06-06T08:10:48.118+00:00",
                "createDate": "2025-06-06T08:10:48.118+00:00",
                "updateDate": "2025-06-06T08:10:48.118+00:00",
                "createdBy": "system",
                "updatedBy": "system"
            }
        ]
     */
    @PostMapping("handleEvents")
    public @ResponseBody ResponseEntity handleCorporateAction(@RequestBody String corporateActionEvent) {
        String status = null;
        status = dataReceiveService.handleCorporateActionEvent(corporateActionEvent);

        return new ResponseEntity<>(status, HttpStatus.OK);
    }
}
