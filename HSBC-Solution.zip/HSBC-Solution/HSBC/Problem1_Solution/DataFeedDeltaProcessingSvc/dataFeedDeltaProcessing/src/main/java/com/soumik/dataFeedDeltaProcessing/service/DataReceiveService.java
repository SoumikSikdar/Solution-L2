package com.soumik.dataFeedDeltaProcessing.service;

import com.soumik.dataFeedDeltaProcessing.model.CorporateActionChangeDetails;
import com.soumik.dataFeedDeltaProcessing.model.CorporateActionEvent;
import com.soumik.dataFeedDeltaProcessing.repo.DataReceiveRepo;
import com.soumik.dataFeedDeltaProcessing.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DataReceiveService {

    @Autowired
    DataReceiveRepo dataReceiveRepo;

    @Autowired
    DeltaDataProcessingService deltaDataProcessingService;

    public String handleCorporateActionEvent(String caEventInputData) {
        String dataPersistStatus;
        try {
            FeedParser parser = identifyParser(caEventInputData);

            // convert the data to a Class object
            List<CorporateActionEvent> newCoacEvent = parser.parse(caEventInputData);

            // validate the feed
            CorporateActionEvent receivedCoacEvent = extractFirstValidEvent(newCoacEvent);
            // now send for processing
            dataPersistStatus = processCorporateActionEvents(receivedCoacEvent);
        } catch (Exception e) {
            throw new InvalidFeedDataException("Exception occurred during parsing");
        }

        return dataPersistStatus;
    }

    private String processCorporateActionEvents(CorporateActionEvent newCoacEvent) {
        String dataPersistStatus;

        // Get current event with event id. Check if events exist
        Long eventId = newCoacEvent.getEventId();
        CorporateActionEvent currentCoacEvent = dataReceiveRepo.findByEventId(eventId);

        // need to pass this to Audit class as Old Value Object during Update Flow
        CorporateActionEvent snapshotObject = ObjectCloner.deepClone(currentCoacEvent, CorporateActionEvent.class);
        Map<String, Object> changedFields = new HashMap<>();

        if (currentCoacEvent == null) {
            //Insert new row
            dataPersistStatus = deltaDataProcessingService.processFeedForInsert(newCoacEvent);
            // call for Audit data save
            publishAuditDetails(newCoacEvent, changedFields, DeltaType.INSERT);
        } else {
            // Update flow
            // Find fields that have changed
            changedFields = deltaDataProcessingService.findChangedFields(currentCoacEvent, newCoacEvent);
            // update entity with only changed fields.
            deltaDataProcessingService.updateCorporateActionEventWithChangedData(currentCoacEvent, changedFields);
            dataPersistStatus = deltaDataProcessingService.processFeedForUpdate(currentCoacEvent);
            // call for Audit data save
            publishAuditDetails(snapshotObject, changedFields, DeltaType.UPDATE);
        }
        return dataPersistStatus;
    }

    private void publishAuditDetails(CorporateActionEvent coacEvent, Map<String, Object> changes, DeltaType changeType) {
        CorporateActionChangeDetails corporateActionChangeDetails = new CorporateActionChangeDetails(coacEvent, changes, changeType);
        // save Audit details
        String auditStatus = deltaDataProcessingService.saveAuditDetails(corporateActionChangeDetails);

    }

    // this returns the parser type depending on the feed type
    public FeedParser identifyParser(String caEventInputData) {
        FeedType type = UtilClass.detectFeedType(caEventInputData);
        FeedParser parser = switch (type) {
            case JSON -> new JsonFeedParser();
            case XML -> new XmlFeedParser();
            case CSV -> new CsvFeedParser();
            default -> throw new UnsupportedOperationException("Unknown feed format");
        };

        return parser;
    }

    // Validation
    private CorporateActionEvent extractFirstValidEvent(List<CorporateActionEvent> events) {
        if (events == null || events.isEmpty()) {
            throw new InvalidFeedDataException("Event list is empty or null");
        }

        return events.stream()
                .filter(e -> e.getEventId() != null)
                .findFirst()
                .orElseThrow(() -> new InvalidFeedDataException("No valid event found"));
    }

}

