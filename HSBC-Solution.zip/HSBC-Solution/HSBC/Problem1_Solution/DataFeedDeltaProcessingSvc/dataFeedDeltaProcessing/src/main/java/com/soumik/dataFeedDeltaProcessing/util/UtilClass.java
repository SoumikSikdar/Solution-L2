package com.soumik.dataFeedDeltaProcessing.util;

public class UtilClass {
    public static FeedType detectFeedType(String content) {
        String trimmed = content.trim();

        if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
            return FeedType.JSON;
        } else if (trimmed.startsWith("<")) {
            return FeedType.XML;
        } else if (trimmed.contains(",") || trimmed.contains(";")) {
            return FeedType.CSV;
        }
        return FeedType.UNKNOWN;
    }
}
