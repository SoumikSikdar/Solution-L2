package com.soumik.dataFeedDeltaProcessing.util;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ObjectCloner {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static <T> T deepClone(T source, Class<T> clazz) {
        return objectMapper.convertValue(source, clazz);
    }
}

