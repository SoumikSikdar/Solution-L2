package com.soumik.dataFeedDeltaProcessing.repo;

import com.soumik.dataFeedDeltaProcessing.model.CorporateActionEvent;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import java.util.List;


@Repository
public interface DataReceiveRepo extends CrudRepository<CorporateActionEvent, Long> {

    CorporateActionEvent findByEventId(Long eventId);

}

