package com.soumik.dataFeedDeltaProcessing.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Component
@Getter
@Setter
@Entity
@Table(name = "CA_EVENT")
public class CorporateActionEvent {

    @Id
    private Long eventId;
    private String eventType;
    private String securityName;
    private String ticker;
    private String sedol;
    private String cusip;
    private String sector;
    private BigDecimal grossRate;
    private BigDecimal fxRate;
    private BigDecimal fees;
    private Date announcementDate;
    private Date effectiveDate;
    private Date paymentDate;
    private Date createDate;
    private Date updateDate;
    private String createdBy;
    private String updatedBy;
    private Long version = 1L;
}

