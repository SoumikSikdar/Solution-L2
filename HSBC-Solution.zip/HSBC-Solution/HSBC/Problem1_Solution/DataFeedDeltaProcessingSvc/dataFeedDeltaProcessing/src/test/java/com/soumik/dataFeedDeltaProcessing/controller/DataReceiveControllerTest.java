package com.soumik.dataFeedDeltaProcessing.controller;

import com.soumik.dataFeedDeltaProcessing.repo.DataReceiveRepo;
import com.soumik.dataFeedDeltaProcessing.service.DataReceiveService;
import com.soumik.dataFeedDeltaProcessing.service.DeltaDataProcessingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(DataReceiveController.class)
@Import(DataReceiveControllerTest.MockConfig.class)
class DataReceiveControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private DataReceiveService dataReceiveService;

    @Autowired
    private DataReceiveRepo dataReceiveRepo;

    private String sampleJson;

    @BeforeEach
    void setup() {
        sampleJson = """
             [
                {
                        "eventId": 4,
                        "eventType": "Dividend",
                        "securityName": "Honda",
                        "ticker": "HON",
                        "sedol": "123MH",
                        "cusip": "2E4RT5M4",
                        "sector": "IT",
                        "grossRate": 67.78,
                        "fxRate": 90.12,
                        "fees": 678.56,
                        "announcementDate": "2025-06-06T08:10:48.118+00:00",
                        "effectiveDate": "2025-06-06T08:10:48.118+00:00",
                        "paymentDate": "2025-06-06T08:10:48.118+00:00",
                        "createDate": "2025-06-06T08:10:48.118+00:00",
                        "updateDate": "2025-06-06T08:10:48.118+00:00",
                        "createdBy": "system",
                        "updatedBy": "system"
                    }
             ]
        """;
    }

    @Test
    void testHandleCorporateAction_Success() throws Exception {
        when(dataReceiveService.handleCorporateActionEvent(anyString()))
                .thenReturn("success");

        mockMvc.perform(post("/handleEvents")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(sampleJson))
                .andExpect(status().isOk())
                .andExpect(content().string("success"));
    }

    @Test
    void testHandleCorporateAction_ServiceThrowsException() throws Exception {
        when(dataReceiveService.handleCorporateActionEvent(anyString()))
                .thenThrow(new RuntimeException("Error while processing"));

        mockMvc.perform(post("/handleEvents")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(sampleJson))
                .andExpect(status().isInternalServerError());
    }

    @TestConfiguration
    static class MockConfig {

        @Bean
        public DataReceiveService dataReceiveService() {
            return mock(DataReceiveService.class);
        }

        @Bean
        public DataReceiveRepo dataReceiveRepo() {
            return mock(DataReceiveRepo.class);
        }

        @Bean
        public DeltaDataProcessingService deltaDataProcessingService() {
            return mock(DeltaDataProcessingService.class);
        }
    }

}

