package com.soumik.dataFeedDeltaProcessing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataFeedDeltaProcessingApplicationTests {

	@Test
	void contextLoads() {
	}

}
