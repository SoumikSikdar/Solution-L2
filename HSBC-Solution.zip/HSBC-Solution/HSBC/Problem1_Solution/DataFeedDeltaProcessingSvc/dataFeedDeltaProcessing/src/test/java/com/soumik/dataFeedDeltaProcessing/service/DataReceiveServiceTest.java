package com.soumik.dataFeedDeltaProcessing.service;


import com.soumik.dataFeedDeltaProcessing.repo.DataReceiveRepo;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.soumik.dataFeedDeltaProcessing.model.CorporateActionEvent;
import com.soumik.dataFeedDeltaProcessing.repo.DataReceiveRepo;
import com.soumik.dataFeedDeltaProcessing.service.DataReceiveService;
import com.soumik.dataFeedDeltaProcessing.service.DeltaDataProcessingService;
import com.soumik.dataFeedDeltaProcessing.util.FeedParser;
import com.soumik.dataFeedDeltaProcessing.util.UtilClass;
import com.soumik.dataFeedDeltaProcessing.util.FeedType;
import com.soumik.dataFeedDeltaProcessing.util.InvalidFeedDataException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

// For mocking static methods
import org.mockito.MockedStatic;
import static org.mockito.Mockito.mockStatic;


@ExtendWith(MockitoExtension.class)
class DataReceiveServiceTest {

    @InjectMocks
    private DataReceiveService dataReceiveService;

    @Mock
    private DataReceiveRepo dataReceiveRepo;

    @Mock
    private DeltaDataProcessingService deltaDataProcessingService;

    private String jsonPayloadSuccess;


    // Optional: stub for static methods like ObjectCloner or UtilClass


    @BeforeEach
    void setup() {
        jsonPayloadSuccess = """
             [
                {
                        "eventId": 4,
                        "eventType": "Dividend",
                        "securityName": "Honda",
                        "ticker": "HON",
                        "sedol": "123MH",
                        "cusip": "2E4RT5M4",
                        "sector": "IT",
                        "grossRate": 67.78,
                        "fxRate": 90.12,
                        "fees": 678.56,
                        "announcementDate": "2025-06-06T08:10:48.118+00:00",
                        "effectiveDate": "2025-06-06T08:10:48.118+00:00",
                        "paymentDate": "2025-06-06T08:10:48.118+00:00",
                        "createDate": "2025-06-06T08:10:48.118+00:00",
                        "updateDate": "2025-06-06T08:10:48.118+00:00",
                        "createdBy": "system",
                        "updatedBy": "system"
                    }
             ]
        """;
    }


    @Test
    void testHandleCorporateActionEvent_InsertFlow_Success() {
        CorporateActionEvent event = new CorporateActionEvent();
        event.setEventId(101L);

        // Mock feed detection
        mockStatic(UtilClass.class);
        when(UtilClass.detectFeedType(anyString())).thenReturn(FeedType.JSON);

        // Stub parser
        FeedParser parser = mock(FeedParser.class);
        when(parser.parse(any())).thenReturn(List.of(event));

        // Inject parser manually if needed (or via strategy map)
        DataReceiveService spy = Mockito.spy(dataReceiveService);
        doReturn(parser).when(spy).identifyParser(any());

        when(dataReceiveRepo.findByEventId(101L)).thenReturn(null);
        when(deltaDataProcessingService.processFeedForInsert(event)).thenReturn("success");

        String result = spy.handleCorporateActionEvent(jsonPayloadSuccess);
        assertEquals("success", result);
    }

    @Test
    void testHandleCorporateActionEvent_UpdateFlow_WithDelta() {
        CorporateActionEvent newEvent = new CorporateActionEvent();
        newEvent.setEventId(200L);
        newEvent.setEventType("Split");

        CorporateActionEvent existingEvent = new CorporateActionEvent();
        existingEvent.setEventId(200L);
        existingEvent.setEventType("Dividend");

        Map<String, Object> deltaMap = Map.of("eventType", "Split");

        mockStatic(UtilClass.class);
        when(UtilClass.detectFeedType(anyString())).thenReturn(FeedType.JSON);

        FeedParser parser = mock(FeedParser.class);
        when(parser.parse(any())).thenReturn(List.of(newEvent));

        DataReceiveService spy = Mockito.spy(dataReceiveService);
        doReturn(parser).when(spy).identifyParser(any());

        when(dataReceiveRepo.findByEventId(200L)).thenReturn(existingEvent);
        when(deltaDataProcessingService.findChangedFields(existingEvent, newEvent)).thenReturn(deltaMap);
        when(deltaDataProcessingService.processFeedForUpdate(any())).thenReturn("success");

        String status = spy.handleCorporateActionEvent("payload");
        assertEquals("success", status);
    }

    @Test
    void testHandleCorporateActionEvent_InvalidEvent_ThrowsException() {
        CorporateActionEvent invalidEvent = new CorporateActionEvent(); // no ID
        mockStatic(UtilClass.class);
        when(UtilClass.detectFeedType(anyString())).thenReturn(FeedType.JSON);

        FeedParser parser = mock(FeedParser.class);
        when(parser.parse(any())).thenReturn(List.of(invalidEvent));

        DataReceiveService spy = Mockito.spy(dataReceiveService);
        doReturn(parser).when(spy).identifyParser(any());

        assertThrows(InvalidFeedDataException.class,
                () -> spy.handleCorporateActionEvent("data"));
    }

    @Test
    void testHandleCorporateActionEvent_ParserFailure_ThrowsException() {
        mockStatic(UtilClass.class);
        when(UtilClass.detectFeedType(anyString())).thenReturn(FeedType.JSON);

        FeedParser parser = mock(FeedParser.class);
        when(parser.parse(any())).thenThrow(new RuntimeException("Parse error"));

        DataReceiveService spy = Mockito.spy(dataReceiveService);
        doReturn(parser).when(spy).identifyParser(any());

        assertThrows(InvalidFeedDataException.class,
                () -> spy.handleCorporateActionEvent("invalid_json"));
    }


}

