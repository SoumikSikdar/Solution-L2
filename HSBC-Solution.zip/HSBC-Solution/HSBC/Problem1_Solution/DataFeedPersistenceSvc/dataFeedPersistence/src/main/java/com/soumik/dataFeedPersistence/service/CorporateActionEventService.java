package com.soumik.dataFeedPersistence.service;

import com.soumik.dataFeedPersistence.model.CorporateActionEvent;
import com.soumik.dataFeedPersistence.repository.CorporateActionEventRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class CorporateActionEventService {

    @Autowired
    CorporateActionEventRepo corporateActionEventRepo;

    public String persistCorporateAction(CorporateActionEvent eventToPersist) {
        corporateActionEventRepo.save(eventToPersist); // JPA tracks only changed fields
        return "SUCCESS";
    }

}
