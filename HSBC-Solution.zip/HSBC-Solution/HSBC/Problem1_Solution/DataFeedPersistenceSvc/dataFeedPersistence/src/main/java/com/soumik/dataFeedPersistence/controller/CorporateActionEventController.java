package com.soumik.dataFeedPersistence.controller;

import com.soumik.dataFeedPersistence.model.CorporateActionEvent;
import com.soumik.dataFeedPersistence.service.CorporateActionEventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
public class CorporateActionEventController {

    @Autowired
    CorporateActionEventService corporateActionEventService;


    @PostMapping("persistEvent")
    public ResponseEntity<String> persistCorporateAction(@RequestBody CorporateActionEvent corporateActionEvent) {
        String status = null;
        status = corporateActionEventService.persistCorporateAction(corporateActionEvent);

        return ResponseEntity.ok("SUCCESS");
    }
}
