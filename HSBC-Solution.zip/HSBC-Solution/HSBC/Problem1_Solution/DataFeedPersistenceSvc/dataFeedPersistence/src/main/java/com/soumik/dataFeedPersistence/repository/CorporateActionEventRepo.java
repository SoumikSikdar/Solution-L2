package com.soumik.dataFeedPersistence.repository;

import com.soumik.dataFeedPersistence.model.CorporateActionEvent;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CorporateActionEventRepo extends CrudRepository<CorporateActionEvent, Long> {
    List<CorporateActionEvent> findAll();

}
