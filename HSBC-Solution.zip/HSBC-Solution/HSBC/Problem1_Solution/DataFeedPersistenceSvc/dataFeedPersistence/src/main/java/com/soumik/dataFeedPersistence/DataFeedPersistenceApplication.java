package com.soumik.dataFeedPersistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataFeedPersistenceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataFeedPersistenceApplication.class, args);
	}

}
