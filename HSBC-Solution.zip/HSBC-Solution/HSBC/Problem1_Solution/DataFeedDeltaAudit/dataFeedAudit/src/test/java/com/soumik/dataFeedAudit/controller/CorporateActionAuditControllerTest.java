package com.soumik.dataFeedAudit.controller;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;
import java.util.ArrayList;

import com.soumik.dataFeedAudit.model.CorporateActionAuditDto;
import com.soumik.dataFeedAudit.model.CorporateActionChangeDetails;
import com.soumik.dataFeedAudit.service.CorporateActionAuditService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import org.springframework.http.ResponseEntity;
import static org.junit.jupiter.api.Assertions.*;

public class CorporateActionAuditControllerTest {

    @Mock
    private CorporateActionAuditService corporateActionAuditService;

    private CorporateActionAuditController controller;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        controller = new CorporateActionAuditController();
        controller.corporateActionAuditService = corporateActionAuditService;
    }

    @Test
    public void testSaveAuditDetails_ReturnsSuccess() {
        CorporateActionChangeDetails request = new CorporateActionChangeDetails();

        when(corporateActionAuditService.saveAuditDetailsService(any(CorporateActionChangeDetails.class)))
                .thenReturn("SUCCESS");

        ResponseEntity<String> response = controller.saveAuditDetails(request);
        assertEquals("SUCCESS", response.getBody());
        assertEquals(200, response.getStatusCodeValue());
    }

    @Test
    public void testGetDeltaChanges_ReturnsAuditDtoList() {
        Long eventId = 123L;
        List<CorporateActionAuditDto> auditList = new ArrayList<>();
        CorporateActionAuditDto dto = new CorporateActionAuditDto();
        auditList.add(dto);

        when(corporateActionAuditService.getDeltaChanges(eq(eventId)))
                .thenReturn(auditList);

        ResponseEntity<List<CorporateActionAuditDto>> response = controller.getDeltaChanges(eventId);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals(auditList, response.getBody());
    }
}


