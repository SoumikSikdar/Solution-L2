package com.soumik.dataFeedAudit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataFeedAuditApplicationTests {

	@Test
	void contextLoads() {
	}

}
