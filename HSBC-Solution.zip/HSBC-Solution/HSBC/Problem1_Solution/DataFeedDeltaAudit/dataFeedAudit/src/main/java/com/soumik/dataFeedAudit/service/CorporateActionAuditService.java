package com.soumik.dataFeedAudit.service;

import com.soumik.dataFeedAudit.model.CorporateActionAuditDto;
import com.soumik.dataFeedAudit.model.CorporateActionChangeDetails;
import com.soumik.dataFeedAudit.model.CorporateActionEvent;
import com.soumik.dataFeedAudit.repo.CorporateActionAuditRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class CorporateActionAuditService {

    @Autowired
    CorporateActionAuditRepo corporateActionAuditRepo;

    public String saveAuditDetailsService(CorporateActionChangeDetails corporateActionChangeDetails) {
        List<CorporateActionAuditDto> caocAuditData = buildAuditDataToSave(corporateActionChangeDetails);
        corporateActionAuditRepo.saveAll(caocAuditData);

        return "Success";

    }

    // build Audit Data to Save
    private List<CorporateActionAuditDto> buildAuditDataToSave(CorporateActionChangeDetails corporateActionChangeDetails) {

        List<CorporateActionAuditDto> coacAuditValues = new ArrayList<>();
        Long eventId = corporateActionChangeDetails.getCorporateActionEvent().getEventId();
        CorporateActionEvent coacEvent = corporateActionChangeDetails.getCorporateActionEvent();

        String changeType = corporateActionChangeDetails.getChangeType().name();

        corporateActionChangeDetails.getChangedFields().forEach((key, value) -> {
            CorporateActionAuditDto auditObj = new CorporateActionAuditDto();
            auditObj.setEventId(eventId);
            auditObj.setChangeType(changeType);
            auditObj.setFieldName(key);

            // set Old value
            if (key.equals("gross_rate")) {
                auditObj.setOldValue(coacEvent.getGrossRate().toString());
            }

            if (key.equals("fx_rate")) {
                auditObj.setOldValue(coacEvent.getFxRate().toString());
            }

            if (key.equals("fees")) {
                auditObj.setOldValue(coacEvent.getFees().toString());
            }

            if (key.equals("effective_date")) {
                auditObj.setOldValue(coacEvent.getEffectiveDate().toString());
            }

            if (key.equals("payment_date")) {
                auditObj.setOldValue(coacEvent.getPaymentDate().toString());
            }

            auditObj.setNewValue(value.toString());
            auditObj.setDateUpdate(new Date());
            auditObj.setUpdatedBy("system");

            // add to the list
            coacAuditValues.add(auditObj);
        });

        return coacAuditValues;


    }

    public List<CorporateActionAuditDto> getDeltaChanges(Long eventId) {
        return corporateActionAuditRepo.findAllByEventId(eventId);
    }
}
