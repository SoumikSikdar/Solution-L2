package com.soumik.dataFeedAudit.util;

public enum DeltaType {
    DELETE,
    INSERT,
    NO_CHANGE,
    UPDATE
}
