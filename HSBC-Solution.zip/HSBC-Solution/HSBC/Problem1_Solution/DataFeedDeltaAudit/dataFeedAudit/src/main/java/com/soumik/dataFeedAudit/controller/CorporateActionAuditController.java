package com.soumik.dataFeedAudit.controller;

import com.soumik.dataFeedAudit.model.CorporateActionAuditDto;
import com.soumik.dataFeedAudit.model.CorporateActionChangeDetails;
import com.soumik.dataFeedAudit.service.CorporateActionAuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CorporateActionAuditController {

    @Autowired
    CorporateActionAuditService corporateActionAuditService;

    @PostMapping("saveDataFeedAudit")
    public ResponseEntity<String> saveAuditDetails(@RequestBody CorporateActionChangeDetails coacChangeDetails) {
        String status = null;
        status = corporateActionAuditService.saveAuditDetailsService(coacChangeDetails);

        return ResponseEntity.ok("SUCCESS");
    }

    @GetMapping("getDeltaChanges")
    public ResponseEntity<List<CorporateActionAuditDto>> getDeltaChanges(@RequestParam("eventId") Long eventId) {
        List<CorporateActionAuditDto> auditDeltaDetails = corporateActionAuditService.getDeltaChanges(eventId);
        return ResponseEntity.ok(auditDeltaDetails);
    }
}
