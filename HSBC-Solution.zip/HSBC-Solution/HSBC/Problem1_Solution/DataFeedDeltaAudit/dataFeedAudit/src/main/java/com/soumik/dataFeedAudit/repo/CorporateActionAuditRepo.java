package com.soumik.dataFeedAudit.repo;

import com.soumik.dataFeedAudit.model.CorporateActionAuditDto;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CorporateActionAuditRepo extends CrudRepository<CorporateActionAuditDto, Long> {
    List<CorporateActionAuditDto> findAllByEventId(Long eventId);
}
