package com.soumik.dataFeedAudit.model;

import com.soumik.dataFeedAudit.util.DeltaType;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.util.Map;

@NoArgsConstructor
@AllArgsConstructor
@Component
@Getter
@Setter
public class CorporateActionChangeDetails {

    private CorporateActionEvent corporateActionEvent;
    private Map<String, Object> changedFields;
    private DeltaType changeType;
}
