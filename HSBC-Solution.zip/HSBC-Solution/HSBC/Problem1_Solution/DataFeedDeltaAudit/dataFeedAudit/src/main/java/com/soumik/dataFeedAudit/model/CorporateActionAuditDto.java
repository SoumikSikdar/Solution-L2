package com.soumik.dataFeedAudit.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Component
@Getter
@Setter
@Entity
@Table(name = "CA_EVENT_AUDIT")
public class CorporateActionAuditDto {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "audit_id_generator")
    @SequenceGenerator(
            name = "eventAudit_id_generator",
            sequenceName = "eventAudit_id_seq",
            allocationSize = 1
    )
    private Long idSeq;
    private Long eventId;
    private String changeType;
    private String fieldName;
    private String oldValue;
    private String newValue;
    private String updatedBy;
    private Date dateUpdate;
}


